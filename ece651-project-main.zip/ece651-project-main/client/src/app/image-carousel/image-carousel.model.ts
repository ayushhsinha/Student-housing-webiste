export interface item {
    public_id: string;
    name: string;
    address: string;
    owner: string; 
    latitude: string; 
    longitude: string; 
  }
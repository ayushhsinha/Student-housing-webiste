type Room = {
  price: number;
  beds: number;
  bathrooms: number;
};

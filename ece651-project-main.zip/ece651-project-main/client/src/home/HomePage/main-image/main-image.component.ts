import { Component } from '@angular/core';

@Component({
  selector: 'app-main-image',
  standalone: true,
  imports: [],
  templateUrl: './main-image.component.html',
  styleUrl: './main-image.component.css'
})
export class MainImageComponent {

}
